#include <gtk/gtk.h>
#include<bits/stdc++.h>
using namespace std;
GtkWidget *window,*img[10],*fix;
const GdkPixbuf *bf;
GdkPixbuf *bf1;
int main(int argc, char *argv[]){
    gtk_init(&argc, &argv);
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window),"ZHS AK JOISC!");
    gtk_window_set_position(GTK_WINDOW(window),GTK_WIN_POS_MOUSE);
    gtk_widget_set_size_request(window,200,200);
    gtk_window_set_resizable(GTK_WINDOW(window), FALSE);
    g_signal_connect(window,"destroy",G_CALLBACK(gtk_main_quit),NULL);
    
    fix=gtk_fixed_new();
    gtk_container_add(GTK_CONTAINER(window),fix);


    for(int i=1;i<=8;i++){
        string ss="r";ss+=i+'0';ss+=".png";
        bf=gdk_pixbuf_new_from_file(ss.c_str(),NULL);
        bf1=gdk_pixbuf_scale_simple(bf,16,16,GDK_INTERP_HYPER);
        img[i]=gtk_image_new_from_pixbuf(bf1);
        gtk_fixed_put(GTK_FIXED(fix),img[i],i,0);
    }
    
    gtk_fixed_move(GTK_FIXED(fix),img[1],10,10);

    gtk_widget_show_all(window);
    gtk_main();
    return 0;
}
