#include"socketqwq.h"
using namespace std;
UDPQWQ js;
int main(){
    js.port=13311;
    js.jsinit(20000);
    while(1){
        string qw;js.recv(qw);
        cout<<qw<<endl;
    }
}