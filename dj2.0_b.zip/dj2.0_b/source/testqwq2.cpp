#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <cstring>
#include <iostream>
using namespace std;
#define PORT 13311
#define IP_ADDRESS "255.255.255.255"
int main() {
    // 创建套接字
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        cerr << "socket error" << endl;
        return -1;
    }
    // 设置目标地址
    struct sockaddr_in servaddr;
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(PORT);
    servaddr.sin_addr.s_addr = inet_addr(IP_ADDRESS);
    // 允许广播
    int broadcast = 1;
    if (setsockopt(sockfd, SOL_SOCKET, SO_BROADCAST, &broadcast, sizeof(broadcast)) < 0) {
        cerr << "setsockopt error" << endl;
        return -1;
    }
    // 发送数据
    const char *sendbuf = "testtest";
    int n = sendto(sockfd, sendbuf, strlen(sendbuf), 0, (sockaddr *)&servaddr, sizeof(servaddr));
    if (n < 0) {
        cerr << "sendto error" << endl;
        return -1;
    }
    cout << "send " << n << " bytes to " << IP_ADDRESS << ":" << PORT << endl;
    // 关闭套接字
    close(sockfd);
    return 0;
}