#include <gtk/gtk.h>
#include<bits/stdc++.h>
using namespace std;
int fxj[4],axflg[4],zt,wz;
GtkWidget *window,*tb,*xglb[2][4],*bt;
void upd(){
    gtk_widget_hide_all(tb);
    if(!zt){
        //cerr<<"*"<<endl;
        gtk_widget_show_all(bt);
        for(int i=0;i<4;i++)if(axflg[i])gtk_widget_show(xglb[0][i]);
    }
    else{int flg=0;
        for(int i=0;i<4;i++)if(axflg[i]){flg=1;break;}
        if(!flg){wz++;if(wz>3){zt=0;upd();return;}}
        gtk_widget_show(xglb[1][wz]);
    }
    gtk_widget_show(tb);
}
void deal_pressed(){zt=1;wz=-1;upd();}
void pr(GtkWidget* widget,GdkEventKey *event,gpointer data){cerr<<"{"<<event->keyval<<"}"<<endl;
    if(!zt){for(int i=0;i<4;i++){if(event->keyval==fxj[i])axflg[i]=1;}upd();}
    else{fxj[wz]=event->keyval;axflg[wz]=1;upd();}
}
void rl(GtkWidget* widget,GdkEventKey *event,gpointer data){cerr<<"["<<event->keyval<<"]"<<endl;
    int flg=0;
    for(int i=0;i<4;i++)if(event->keyval==fxj[i]&&axflg[i]){axflg[i]=0;flg=1;}
    if(flg)upd();
}
void deal_close(){
    FILE *fp=fopen("opt.in","w");
    for(int i=0;i<4;i++)fprintf(fp,"%d ",fxj[i]);
    fflush(fp);fclose(fp);
}
int main(int argc,char *argv[]){
    gtk_init(&argc, &argv);

    FILE *fp=fopen("opt.in","r");
    for(int i=0;i<4;i++)fscanf(fp,"%d",&fxj[i]);
    fclose(fp);

    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window),"Options");
    gtk_window_set_position(GTK_WINDOW(window),GTK_WIN_POS_MOUSE);
    gtk_widget_set_size_request(window,400,200);
    gtk_window_set_resizable(GTK_WINDOW(window), TRUE);
    g_signal_connect(window,"destroy",G_CALLBACK(deal_close),NULL);
    g_signal_connect(window,"destroy",G_CALLBACK(gtk_main_quit),NULL);

    tb=gtk_table_new(2,4,FALSE);gtk_container_add(GTK_CONTAINER(window),tb);
    xglb[0][0]=gtk_label_new("Up");gtk_table_attach_defaults(GTK_TABLE(tb),xglb[0][0],0,1,0,1);
    xglb[0][1]=gtk_label_new("Down");gtk_table_attach_defaults(GTK_TABLE(tb),xglb[0][1],1,2,0,1);
    xglb[0][2]=gtk_label_new("Left");gtk_table_attach_defaults(GTK_TABLE(tb),xglb[0][2],2,3,0,1);
    xglb[0][3]=gtk_label_new("Right");gtk_table_attach_defaults(GTK_TABLE(tb),xglb[0][3],3,4,0,1);
    xglb[1][0]=gtk_label_new("Please press up");gtk_table_attach_defaults(GTK_TABLE(tb),xglb[1][0],0,1,0,1);
    xglb[1][1]=gtk_label_new("Please press down");gtk_table_attach_defaults(GTK_TABLE(tb),xglb[1][1],0,1,0,1);
    xglb[1][2]=gtk_label_new("Please press left");gtk_table_attach_defaults(GTK_TABLE(tb),xglb[1][2],0,1,0,1);
    xglb[1][3]=gtk_label_new("Please press right");gtk_table_attach_defaults(GTK_TABLE(tb),xglb[1][3],0,1,0,1);
    bt=gtk_button_new_with_label("Change");gtk_table_attach_defaults(GTK_TABLE(tb),bt,0,4,1,2);
    g_signal_connect(window,"key_press_event",G_CALLBACK(pr),NULL);
    g_signal_connect(window,"key_release_event",G_CALLBACK(rl),NULL);
    g_signal_connect(bt,"pressed",G_CALLBACK(deal_pressed),NULL); 
    gtk_widget_show(bt);gtk_widget_show(tb);gtk_widget_show(window);
    
    gtk_main();
}