#include"socketqwq.h"
using namespace std;
UDPQWQ fs;
int main(){
    fs.port=13311;
    fs.fsinit(20000);
    while(1){
        usleep(200000);
        fs.send("testtest");
    }
}