#include <gtk/gtk.h>
#include"socketqwq.h"
#include<bits/stdc++.h>
using namespace std;
guint timer;
int nb,port_out=12321,port_in=12322,qqwqq=1e9,ksflg;
GtkWidget *window,*tb,*xjbt,*xjlb,*rslb,*ksbt,*qaqlb;
UDPQWQ fs,js;
long long gtnbc(string &s,int &qs){
    long long sh=0,js=s.size();js--;
    while(qs<=js&&(s[qs]<'0'||'9'<s[qs]))qs++;
    while(qs<=js&&('0'<=s[qs]&&s[qs]<='9')){sh=(sh<<1)+(sh<<3)+(s[qs]^48);qs++;}
    return sh;
}
bool chkc(char c){
    if((c<'0'||'9'<c)&&(c<'a'||'z'<c)&&(c<'A'||'Z'<c)&&c!='_')return false;
    return true;
}
string gtstrc(string &s,int &qs){
    string sh;int js=s.size();js--;
    while(qs<=js&&(!chkc(s[qs])))qs++;
    while(qs<=js&&chkc(s[qs])){sh+=s[qs];qs++;}
    return sh;
}
void ptnbc(string &s,long long zh){
    if(!zh){s+='0';return;}
    int qw=zh%10;ptnbc(s,zh/10);s+=qw+'0';
}
struct REN{
    string nm;
    int czflg,smz,sc,zx,zy,aj[4],fangx,pdd,ttflg;
    long long pzsj;
    double fx,fy,vx,vy,x,y;
};
mt19937 rrndd(random_device{}());
struct GAME{
    long long updcnt=0;
    const int rslim=8;
    int n,m,sd,op,smz,opy,t,p1,q1,p2,q2,rs,opz;
    double v0,a,v,nwh,xlim=10,ylim=2;
    int sx[10];
    int randd(int l,int r){return (rrndd()%(r-l+1))+l;}
    REN ren[10];
    vector<int>cswz;
    vector<vector<int> >ma;
    int pdpz(int x,int y){
    	if(ren[x].zx+16==ren[y].zx&&((ren[y].zy<=ren[x].zy&&ren[x].zy<=ren[y].zy+15)||(ren[y].zy<=ren[x].zy+15&&ren[x].zy+15<=ren[y].zy+15)))return 1;//xia
    	if(ren[y].zy+16==ren[x].zy&&((ren[y].zx<=ren[x].zx&&ren[x].zx<=ren[y].zx+15)||(ren[y].zx<=ren[x].zx+15&&ren[x].zx+15<=ren[y].zx+15)))return 2;//zuo
    	if(ren[x].zy+16==ren[y].zy&&((ren[y].zx<=ren[x].zx&&ren[x].zx<=ren[y].zx+15)||(ren[y].zx<=ren[x].zx+15&&ren[x].zx+15<=ren[y].zx+15)))return 3;//you
    	return 0;
	}
    bool pdy(int x,int y){
        return ((ren[y].y<=ren[x].y&&ren[x].y<ren[y].y+16)||(ren[y].y<ren[x].y+16&&ren[x].y+16<=ren[y].y+16));
    }
    bool pdx(int x,int y){
        return ((ren[y].x<=ren[x].x&&ren[x].x<ren[y].x+16)||(ren[y].x<ren[x].x+16&&ren[x].x+16<=ren[y].x+16));
    }
    void jifei1(int i){//cerr<<"*"<<endl;
        if(ren[i].smz){//cerr<<"&"<<endl;
            ren[i].smz--;if(ren[i].pdd&&updcnt-ren[i].pzsj<=100){ren[ren[i].pdd].sc++;ren[i].pdd=0;}
            if(!opz){ren[i].x=ren[i].zx=20;ren[i].y=ren[i].zy=20*(i+1);}
            else{ren[i].x=ren[i].zx=20;ren[i].y=ren[i].zy=cswz[randd(0,cswz.size()-1)]*20+2;ren[i].vx=ren[i].fx=ren[i].zx=ren[i].vy=ren[i].fy=ren[i].zy=0;}
        }
    }
    double jump_h=5;
    void upd(){updcnt++;
        /*for(int i=0;i<=n+1;i++){
            for(int j=0;j<=m+1;j++){
                cout<<ma[i][j];
            }puts("");
        }exit(0);*/
        random_shuffle(sx+1,sx+rslim+1);
        for(int ii=1;ii<=rslim;ii++){
        	int i=sx[ii];if(!ren[i].czflg)continue;
        	//-------------------------------------f v
        	ren[i].fx=0.15;//if(ren[i].aj[0])ren[i].fx=0.0002;//da tiao
        	if(ren[i].aj[0]){//tiao
                if(ren[i].ttflg)ren[i].vx-=jump_h*0.3;
        		//ping di tiao
        		int pdtflg=0;
        		for(int jj=1;jj<=rslim;jj++){
        			int j=sx[jj];if(!ren[j].czflg)continue;
        			if(pdpz(i,j)==1){pdtflg=1;ren[j].vx+=jump_h;ren[j].pdd=i;ren[j].pzsj=updcnt;break;}
				}
				if((ren[i].zx+16)%20==0){
					int hh=(ren[i].zx+16)/20;
					if(ma[hh][ren[i].zy/20]||ma[hh][(ren[i].zy+15)/20]){pdtflg=1;}
				}
				if(pdtflg){ren[i].vx=-jump_h*0.7;ren[i].ttflg=1;}
                else ren[i].ttflg=0;
        		//xiang zuo ceng qiang tiao
        		int tflg=0;
                if(ren[i].aj[3]){
                    if(!pdtflg){
                        for(int jj=1;jj<=rslim;jj++){
                            int j=sx[jj];if(!ren[j].czflg)continue;
                            if(pdpz(i,j)==2){tflg=1;ren[j].vx+=jump_h*0.85;ren[j].vy-=1.5;ren[j].pdd=i;ren[j].pzsj=updcnt;break;}
                        }        			
                    }
                    if(ren[i].zy%20==0){
                        int ll=(ren[i].zy/20)-1;
                        if(ma[ren[i].zx/20][ll]||ma[(ren[i].zx+15)/20][ll])tflg=1;
                    }
                    if(!pdtflg&&tflg){ren[i].vx=max(ren[i].vx-jump_h*0.85,-jump_h*0.85);ren[i].vy=0.8;}
                }
        		//xiang you ceng qiang tiao
        		tflg=0;
                if(ren[i].aj[2]){
                    if(!pdtflg){
                        for(int jj=1;jj<=rslim;jj++){
                            int j=sx[jj];if(!ren[j].czflg)continue;
                            if(pdpz(i,j)==3){tflg=1;ren[j].vx+=jump_h*0.85;ren[j].vy+=1.5;ren[j].pdd=i;ren[j].pzsj=updcnt;break;}
                        }        			
                    }
                    if((ren[i].zy+16)%20==0){
                        int ll=(ren[i].zy+16)/20;
                        if(ma[ren[i].zx/20][ll]||ma[(ren[i].zx+15)/20][ll])tflg=1;
                    }
                    if(!pdtflg&&tflg){ren[i].vx=max(ren[i].vx-jump_h*0.85,-jump_h*0.85);ren[i].vy=-0.8;}
                }
			}int owflg=0;
        	//zuo
        	if(ren[i].aj[2]&&(!ren[i].aj[3])){ren[i].fy=-0.12;owflg=1;}
        	//you
        	if(ren[i].aj[3]&&(!ren[i].aj[2])){ren[i].fy=0.12;owflg=1;}

            if(!owflg)ren[i].fy=0;
            
            ren[i].vx+=ren[i].fx;if(ren[i].vx>xlim){ren[i].vx=xlim;}if(ren[i].vx<-xlim){ren[i].vx=-xlim;}
            ren[i].vy+=ren[i].fy;if(ren[i].vy>0){ren[i].vy=max(ren[i].vy-0.04,0.0);}if(ren[i].vy<0){ren[i].vy=min(ren[i].vy+0.04,0.0);}
            if(ren[i].vy>ylim){ren[i].vy=ylim;}if(ren[i].vy<-ylim){ren[i].vy=-ylim;}
        	//-------------------------------------wei zhi
        	if(ren[i].vx>0){
                int hh=(ren[i].x+16)/20+1,flgg=0;if((hh-1)*20>=ren[i].x+16)hh--;
                int qwql=ren[i].y/20,qwqr=(ren[i].y+16)/20;if(qwqr*20>=ren[i].y+16)qwqr--;
                double jl=ren[i].vx;
                if(ma[hh][qwql]||ma[hh][qwqr]){
                    if(hh*20-ren[i].x-16<jl){jl=hh*20-ren[i].x-16;flgg=-1;}
                }
        		for(int jj=1;jj<=rslim;jj++){
        			int j=sx[jj];if(!ren[j].czflg)continue;
        			if(ren[i].x+16<=ren[j].x&&pdy(i,j)&&ren[j].x-ren[i].x-16<jl){
                        jl=ren[j].x-ren[i].x-16;flgg=j;
                    }
				}
                ren[i].x+=jl;if(flgg<0){/*ren[i].vx=-ren[i].vx*0.3;*//*ren[i].pdd=0;*/}
                else if(flgg>0){ren[i].vx=ren[flgg].vx=(ren[i].vx+ren[flgg].vx)/2;if(abs(jl)>1e-9){ren[i].pdd=flgg;ren[flgg].pdd=i;ren[i].pzsj=ren[flgg].pzsj=updcnt;}}
                ren[i].vx=jl;//if(flgg<0)cout<<"*";
            }
            else{
                int hh=ren[i].x/20-1,flgg=0;
                int qwql=ren[i].y/20,qwqr=(ren[i].y+16)/20;if(qwqr*20>=ren[i].y+16)qwqr--;
                double jl=ren[i].vx;
                if(ma[hh][qwql]||ma[hh][qwqr]){
                    if((hh+1)*20-ren[i].x>jl){jl=(hh+1)*20-ren[i].x;flgg=-1;}
                }
        		for(int jj=1;jj<=rslim;jj++){
        			int j=sx[jj];if(!ren[j].czflg)continue;
        			if(ren[i].x>=ren[j].x+16&&pdy(i,j)&&ren[j].x+16-ren[i].x>jl){
                        jl=ren[j].x+16-ren[i].x;flgg=j;
                    }
				}
                ren[i].x+=jl;if(flgg<0){ren[i].vx=-ren[i].vx*0.5;}
                else if(flgg>0){ren[i].vx=ren[flgg].vx=(ren[i].vx+ren[flgg].vx)/2;if(abs(jl)>1e-9){ren[i].pdd=flgg;ren[flgg].pdd=i;ren[i].pzsj=ren[flgg].pzsj=updcnt;}}
                ren[i].vx=jl;//if(flgg<0)cout<<"$";
            }
            if(ren[i].vy>0){
                int hh=(ren[i].y+16)/20+1,flgg=0;if((hh-1)*20>=ren[i].y+16)hh--;
                int qwql=ren[i].x/20,qwqr=(ren[i].x+16)/20;if(qwqr*20>=ren[i].x+16)qwqr--;
                double jl=ren[i].vy;
                if(ma[qwql][hh]||ma[qwqr][hh]){
                    if(hh*20-ren[i].y-16<jl){jl=hh*20-ren[i].y-16;flgg=-1;}
                }
                for(int jj=1;jj<=rslim;jj++){
                    int j=sx[jj];
                    if(!ren[j].czflg)continue;
                    if(ren[i].y+16<=ren[j].y&&pdx(i,j)&&ren[j].y-ren[i].y-16<jl){
                        jl=ren[j].y-ren[i].y-16;flgg=j;
                    }
                }//cerr<<"{"<<ren[i].y<<" "<<jl<<"}"<<endl;
                ren[i].y+=jl;
                if(flgg<0){/*ren[i].vy=-ren[i].vy*0.3;*/ren[i].vy=jl;}
                else if(flgg>0){ren[i].vy=ren[flgg].vy=(ren[i].vy+ren[flgg].vy)/2;if(abs(jl)>1e-9){ren[i].pdd=flgg;ren[flgg].pdd=i;ren[i].pzsj=ren[flgg].pzsj=updcnt;}}
                //if(flgg<0)cout<<"#";
            }
            else{
                int hh=ren[i].y/20-1,flgg=0;//cerr<<"{"<<hh<<"}"<<endl;
                int qwql=ren[i].x/20,qwqr=(ren[i].x+16)/20;if(qwqr*20>=ren[i].x+16)qwqr--;
                double jl=ren[i].vy;
                if(ma[qwql][hh]||ma[qwqr][hh]){
                    if((hh+1)*20-ren[i].y>jl){jl=(hh+1)*20-ren[i].y;flgg=-1;}
                }
                for(int jj=1;jj<=rslim;jj++){
                    int j=sx[jj];
                    if(!ren[j].czflg)continue;
                    if(ren[i].y>=ren[j].y+16&&pdx(i,j)&&ren[j].y+16-ren[i].y>jl){
                        jl=ren[j].y+16-ren[i].y;flgg=j;
                    }
                }//cerr<<"{"<<ren[i].y<<" "<<jl<<"}"<<endl;
                ren[i].y+=jl;
                if(flgg<0){/*ren[i].vy=-ren[i].vy*0.3;*/ren[i].vy=jl;}
                else if(flgg>0){ren[i].vy=ren[flgg].vy=(ren[i].vy+ren[flgg].vy)/2;if(abs(jl)>1e-9){ren[i].pdd=flgg;ren[flgg].pdd=i;ren[i].pzsj=ren[flgg].pzsj=updcnt;}}
                //if(flgg<0)cout<<"%";
            }
            //---------------------------------------------------------------------
            ren[i].zx=ren[i].x+0.5;ren[i].zy=ren[i].y+0.5;
            if(!op){
                if(ren[i].zx==20&&ren[i].fangx==0)ren[i].fangx=1;
                else if(ren[i].zx==(n+1)*20-16&&ren[i].fangx==1){ren[i].smz++;ren[i].fangx=0;if(ren[i].smz>=smz){ren[i].smz=smz;ren[i].fangx=2;}}
            }
            else if(op==1){
                if(ren[i].zx%20==0&&(ma[ren[i].zx/20-1][ren[i].zy/20]==2||ma[ren[i].zx/20-1][(ren[i].zy+15)/20]==2))jifei1(i);
                if((ren[i].zx+16)%20==0&&(ma[(ren[i].zx+16)/20][ren[i].zy/20]==2||ma[(ren[i].zx+16)/20][(ren[i].zy+15)/20]==2))jifei1(i);
                if(ren[i].zy%20==0&&(ma[ren[i].zx/20][ren[i].zy/20-1]==2||ma[(ren[i].zx+15)/20][ren[i].zy/20-1]==2))jifei1(i);
                if((ren[i].zy+16)%20==0&&(ma[ren[i].zx/20][(ren[i].zy+16)/20]==2||ma[(ren[i].zx+15)/20][(ren[i].zy+16)/20]==2))jifei1(i);
            }//cout<<"["<<ren[i].x<<" "<<ren[i].y<<" "<<ren[i].vx<<" "<<ren[i].vy<<" "<<ren[i].fx<<" "<<ren[i].fy<<"]"<<endl;
		}
    }    
    void init(){//freopen("test.out","w",stdout);
        mt19937 rnd(sd);
        ma.resize(n+2);
        for(int i=1;i<=rslim;i++)sx[i]=i;
        for(int i=0;i<=n+1;i++)ma[i].resize(m+2);
        for(int i=1;i<=n;i++){
            for(int j=1;j<=m;j++){
                if(rnd()%q1<p1){
                    if(rnd()%q2<p2)ma[i][j]=2;
                    else ma[i][j]=1;
                }
            }
        }
        for(int i=0;i<=n+1;i++){
            if(!opy)ma[i][0]=ma[i][m+1]=1;
            else if(opy==1)ma[i][0]=ma[i][m+1]=2;
            else{
                if(rnd()%q2<p2){ma[i][0]=2;}else ma[i][0]=1;
                if(rnd()%q2<p2){ma[i][m+1]=2;}else ma[i][m+1]=1;                
            }
        }
        for(int i=1;i<=m;i++){ma[0][i]=ma[n+1][i]=1;if(op==1)ma[n+1][i]=2;}
        if(op==0){
            for(int i=1;i<=rslim;i++){ma[n][i]=0;ren[i].x=ren[i].zx=n*20;ren[i].y=ren[i].zy=i*20;}
        }
        else{
            for(int i=1;i<=n;i++){if(ma[i][0]==1){ma[i][1]=0;}if(ma[i][m+1]==1){ma[i][m]=0;}}
            for(int i=1;i<=n;i++){
                for(int j=1;j<=m;j++){
                    if(ma[i][j]!=1)continue;
                    if(ma[i-1][j-1]==1||ma[i-1][j+1]==1)ma[i][j]=0;
                }
            }
            for(int i=1;i<=m;i++)ma[1][i]=0;
            for(int i=1;i<=rslim;i++)ren[i].smz=smz;
            if(!opz){
                for(int i=2;i<=rslim+1;i++){ma[2][i]=1;ren[i-1].x=ren[i-1].zx=20;ren[i-1].y=ren[i-1].zy=20*i;}
            }
            else{
                for(int i=1;i<=m;i++){
                    for(int j=1;j<=n;j++){
                        if(ma[j][i]==1){cswz.push_back(i);break;}
                        if(ma[j][i]==2)break;
                    }
                }if(!cswz.size()){cswz.push_back(2);ma[2][2]=1;}
                for(int i=2;i<=rslim+1;i++){ren[i-1].x=ren[i-1].zx=20;ren[i-1].y=ren[i-1].zy=cswz[randd(0,cswz.size()-1)]*20+2;}
            }
        }
        /*for(int i=0;i<=n+1;i++){
            for(int j=0;j<=m+1;j++){
                cout<<ma[i][j];
            }puts("");
        }exit(0);*/
    }
}gmo;
void startt(){
    ksflg=1;
    gtk_widget_hide(tb);
    string ss;ptnbc(ss,nb);ss+=" 1 ";ptnbc(ss,gmo.n);ss+=" ";ptnbc(ss,gmo.m);ss+=" ";
    ptnbc(ss,gmo.sd);ss+=" ";ptnbc(ss,gmo.op);ss+=" ";ptnbc(ss,gmo.opy);ss+=" ";
    ptnbc(ss,gmo.p1);ss+=" ";ptnbc(ss,gmo.q1);ss+=" ";ptnbc(ss,gmo.p2);ss+=" ";
    ptnbc(ss,gmo.q2);ss+=" ";ptnbc(ss,gmo.rs);ss+=" ";ptnbc(ss,gmo.opz);ss+=" ";
    for(int i=1;i<=gmo.rslim;i++)if(gmo.ren[i].czflg){ss+=gmo.ren[i].nm;ss+=" ";}
    fs.send(ss);gmo.init();
    usleep(500000);
}
bool gemo(){//cerr<<"*"<<endl;
    if(!ksflg){
        string ss;
        while(1){
            js.recv(ss);if(!ss.size())break;
            int nwwz=0;long long x=gtnbc(ss,nwwz);if(x!=nb)continue;
            x=gtnbc(ss,nwwz);
            if(!x){
                for(int i=1;i<=gmo.rslim;i++)if(!gmo.ren[i].czflg){gmo.rs++;
                    string sss;ptnbc(sss,nb);sss+=" 0 ";sss+=gtstrc(ss,nwwz);sss+=' ';ptnbc(sss,i);fs.send(sss);
                    gmo.ren[i].czflg=1;gmo.ren[i].nm=gtstrc(ss,nwwz);
                    string rss="Number of people:";rss+=gmo.rs+'0';
                    gtk_label_set_text(GTK_LABEL(rslb),rss.c_str());
                    break;
                }
            }
            else if(x==1){
                int bhh=gtnbc(ss,nwwz);gmo.ren[bhh].czflg=0;gmo.rs--;
                string rss="Number of people:";rss+=gmo.rs+'0';
                gtk_label_set_text(GTK_LABEL(rslb),rss.c_str());
            }
            else if(x==3){
                string sss;ptnbc(sss,nb);sss+=" 3 ";fs.send(sss);
            }
        }
    }
    else{
        string ss;
        while(1){
            js.recv(ss);if(!ss.size())break;
            int nwwz=0;long long x=gtnbc(ss,nwwz);if(x!=nb)continue;
            x=gtnbc(ss,nwwz);if(x==3){string sss;ptnbc(sss,nb);sss+=" 3 ";fs.send(sss);}
            if(x!=2)continue;
            int rbh=gtnbc(ss,nwwz);int jian=gtnbc(ss,nwwz);
            gmo.ren[rbh].aj[jian]=gtnbc(ss,nwwz);
        }
        int gxcs=1;
        while(gxcs--)gmo.upd();
        ss="";ptnbc(ss,nb);ss+=" 2 ";
        for(int i=1;i<=gmo.rslim;i++){
            if(gmo.ren[i].czflg){
                ptnbc(ss,i);ss+=" ";
                ptnbc(ss,gmo.ren[i].zx);ss+=" ";
                ptnbc(ss,gmo.ren[i].zy);ss+=" ";
            }
        }
        if(!gmo.op){
            for(int i=1;i<=gmo.rslim;i++)if(gmo.ren[i].czflg){
                ptnbc(ss,gmo.ren[i].smz);ss+=" ";
            }
            for(int i=1;i<=gmo.rslim;i++)if(gmo.ren[i].czflg){ss+=gmo.ren[i].fangx+'0';ss+=" ";}
        }
        else if(gmo.op==1){
            for(int i=1;i<=gmo.rslim;i++)if(gmo.ren[i].czflg){
                ptnbc(ss,gmo.ren[i].smz);ss+=" ";
            }
            for(int i=1;i<=gmo.rslim;i++)if(gmo.ren[i].czflg){
                ptnbc(ss,gmo.ren[i].sc);ss+=" ";
            }
        }fs.send(ss);
    }return true;
}

void initrm(){
    FILE *fp=fopen("test.in","r");
    fscanf(fp,"%d%d%d%d",&nb,&gmo.n,&gmo.m,&gmo.sd);
    if(nb<0||nb>qqwqq){puts("nb QAQ!");gtk_widget_show(qaqlb);return;}
    int qwqq=1e6;if(gmo.n<10){puts("n QAQ!");gtk_widget_show(qaqlb);return;}
    if(gmo.m<10){puts("m QAQ!");gtk_widget_show(qaqlb);return;}
    if(gmo.n*gmo.m>qwqq){puts("n*m QAQ!");gtk_widget_show(qaqlb);return;}
    if(gmo.sd<-1||gmo.sd>qqwqq){puts("sd QAQ!");gtk_widget_show(qaqlb);return;}
    fscanf(fp,"%d%d%d%d",&gmo.p1,&gmo.q1,&gmo.p2,&gmo.q2);
    if(gmo.p1<0||qqwqq<gmo.p1){puts("p1 QAQ");gtk_widget_show(qaqlb);return;}
    if(gmo.q1<1||qqwqq<gmo.q1){puts("q1 QAQ");gtk_widget_show(qaqlb);return;}
    if(gmo.p2<0||qqwqq<gmo.p2){puts("p2 QAQ");gtk_widget_show(qaqlb);return;}
    if(gmo.q2<1||qqwqq<gmo.q2){puts("q2 QAQ");gtk_widget_show(qaqlb);return;}
    fscanf(fp,"%d%d%d%d",&gmo.op,&gmo.smz,&gmo.opy,&gmo.opz);
    if(gmo.op<0||1<gmo.op){puts("op QAQ!");gtk_widget_show(qaqlb);return;}
    if(gmo.smz<1||100<gmo.smz){puts("x QAQ!");gtk_widget_show(qaqlb);return;}
    if(gmo.opy<0||2<gmo.opy){puts("y QAQ!");gtk_widget_show(qaqlb);return;}
    if(gmo.opz<0||1<gmo.opz){puts("z QAQ!");gtk_widget_show(qaqlb);return;}
    fscanf(fp,"%d%lf%lf%lf",&gmo.t,&gmo.v0,&gmo.a,&gmo.v);
    if(gmo.t<0||600<gmo.t){puts("t QAQ!");gtk_widget_show(qaqlb);return;}
    if(gmo.v0<=0||20<gmo.v0){puts("v0 QAQ!");gtk_widget_show(qaqlb);return;}
    if(gmo.a<0||20<gmo.a){puts("a QAQ!");gtk_widget_show(qaqlb);return;}
    if(gmo.v<=0||20<gmo.v){puts("v QAQ!");gtk_widget_show(qaqlb);return;}

    string ss;ptnbc(ss,nb);ss+=" 3 ";int sbflg=0;
    UDPQWQ fss,jss;
    fss.port=port_in;fss.fsinit(10);
    jss.port=port_out;jss.jsinit(10);     
    fss.send(ss);usleep(200000);
    while(1){jss.recv(ss);
        if(!ss.size())break;
        int nwwz=0;long long x=gtnbc(ss,nwwz);if(x!=nb)continue;
        x=gtnbc(ss,nwwz);if(x!=3)continue;
        sbflg=1;break;
    }fss.cls();jss.cls();
    if(sbflg){puts("nb QAQAQ!");gtk_widget_show(qaqlb);return;}

    fs.port=port_out;fs.fsinit(10);
    js.port=port_in;js.jsinit(10); 
    if(gmo.sd==-1){gmo.sd=random_device{}();if(gmo.sd<0)gmo.sd=-gmo.sd;}
    if(gmo.op==0){gmo.p2=0;gmo.opy=0;}
    g_signal_connect(ksbt,"pressed",G_CALLBACK(startt),NULL); 
    gtk_widget_hide(xjlb);gtk_widget_hide(xjbt);gtk_widget_hide(qaqlb);
    gtk_widget_show(rslb);gtk_widget_show(ksbt);
    timer=g_timeout_add(20,(GSourceFunc)gemo,NULL);

}
void deal_close(){
    /*for(int i=0;i<=gmo.n+1;i++){
        for(int j=0;j<=gmo.m+1;j++){
            cout<<gmo.ma[i][j];
        }puts("");
    }*/
}
void init(){
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window),"WYD AK NOI!");
    gtk_window_set_position(GTK_WINDOW(window),GTK_WIN_POS_MOUSE);
    gtk_widget_set_size_request(window,400,200);
    gtk_window_set_resizable(GTK_WINDOW(window), FALSE);
    g_signal_connect(window,"destroy",G_CALLBACK(deal_close),NULL);
    g_signal_connect(window,"destroy",G_CALLBACK(gtk_main_quit),NULL);

    tb=gtk_table_new(3,1,FALSE);gtk_container_add(GTK_CONTAINER(window),tb);
    xjlb=gtk_label_new("输入格式见readme.txt\n输入完按OK");
    gtk_table_attach_defaults(GTK_TABLE(tb),xjlb,0,1,0,1);gtk_widget_show(xjlb);
    qaqlb=gtk_label_new("QAQ!");gtk_table_attach_defaults(GTK_TABLE(tb),qaqlb,0,1,1,2);
    xjbt=gtk_button_new_with_label("OK");gtk_table_attach_defaults(GTK_TABLE(tb),xjbt,0,1,2,3);gtk_widget_show(xjbt);
    rslb=gtk_label_new("Number of people:0");gtk_table_attach_defaults(GTK_TABLE(tb),rslb,0,1,0,1);
    ksbt=gtk_button_new_with_label("Start");gtk_table_attach_defaults(GTK_TABLE(tb),ksbt,0,1,2,3);

    g_signal_connect(xjbt,"pressed",G_CALLBACK(initrm),NULL); 
    gtk_widget_show(tb);gtk_widget_show(window);
   

}
int main(int argc,char *argv[]){
    gtk_init(&argc,&argv);
    init();
    gtk_main();
}/*
note:
创建房间时还没判断是否有相同编号房间
*/