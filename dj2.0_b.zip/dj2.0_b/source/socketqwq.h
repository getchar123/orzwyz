#include<bits/stdc++.h>
#include<unistd.h>
#include<sys/select.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<netinet/in.h>
#include <net/if.h>
using namespace std;
struct UDPQWQ{
    int port,sockfd;//port:端口
    struct timeval tv;
    struct sockaddr_in addr;
    socklen_t addr_len;
    bool fsinit(int timeqwq){
        sockfd=socket(AF_INET,SOCK_DGRAM,0);if(sockfd==-1)return false;
        //addr_len=sizeof(addr);
        memset(&addr,0,sizeof(addr));
        addr.sin_family=AF_INET;       // Use IPV4
        addr.sin_port=htons(port);    //
        //addr.sin_addr.s_addr=htonl(INADDR_ANY);
        addr.sin_addr.s_addr = inet_addr("255.255.255.255");
        tv.tv_sec=0;
        tv.tv_usec=timeqwq;
        setsockopt(sockfd,SOL_SOCKET,SO_RCVTIMEO,(const char*)&tv,sizeof(struct timeval));
        int broadcast = 1;
        if (setsockopt(sockfd, SOL_SOCKET, SO_BROADCAST, &broadcast, sizeof(broadcast)) < 0) {
            cerr << "setsockopt error" << endl;
            return false;
        }return true;
    }
    void send(string s){
        addr.sin_family=AF_INET;
        addr.sin_port=htons(port);
        //addr.sin_addr.s_addr=htonl(INADDR_ANY);
        addr.sin_addr.s_addr = inet_addr("255.255.255.255");
        sendto(sockfd,s.c_str(),s.size(),0,(sockaddr*)&addr,sizeof(addr));
        //cerr<<"send:("<<s<<")"<<endl;
    }
    bool jsinit(int timeqwq){
        sockfd=socket(AF_INET,SOCK_DGRAM,0);if(sockfd==-1)return false;
        //addr_len=sizeof(addr);
        memset(&addr,0,sizeof(addr));
        addr.sin_family=AF_INET;       // Use IPV4
        addr.sin_port=htons(port);    //
        addr.sin_addr.s_addr=htonl(INADDR_ANY);
        tv.tv_sec=0;
        tv.tv_usec=timeqwq;
        setsockopt(sockfd,SOL_SOCKET,SO_RCVTIMEO,(const char*)&tv,sizeof(struct timeval));
        if(bind(sockfd,(struct sockaddr*)&addr,sizeof(addr))==-1){close(sockfd);return false;}
        return true;
    }
    void recv(string &s){s="";
        char buffer[1024];memset(buffer,0,1024);
        struct sockaddr_in src;
        socklen_t src_len=sizeof(src);
        memset(&src,0,sizeof(src));
        int sz=recvfrom(sockfd,buffer,1024,0,(sockaddr*)&src,&src_len);
        for(int i=0;i<sz;i++)s+=buffer[i];
        //if(s.size())cerr<<"recv:("<<s<<")"<<endl;
    }
    void cls(){close(sockfd);}
    void clr(){string ss;while(1){recv(ss);if(!ss.size()){break;}ss="";}}
};