#include <gtk/gtk.h>
#include"socketqwq.h"
using namespace std;
guint timer;
GtkWidget *window,*window1,*qdbt,*nmqaq,*nbqaq,*srnm,*srnb,*lbnm,*lbnb,*tb,*waitt,*fix,*rking;
const gchar *nm,*Nb;
int nmlen,nblen,nb,port_in=12321,port_out=12322,mybh,ksflg,ajm[4],ajf[4],gzbh=1,RS;//12321 12322
UDPQWQ fs,js;
int gtnbgc(const gchar *s,int qs,int js){
    int sh=0;
    while(qs<=js&&(s[qs]<'0'||'9'<s[qs]))qs++;
    while(qs<=js&&('0'<=s[qs]&&s[qs]<='9')){sh=(sh<<1)+(sh<<3)+(s[qs]^48);qs++;}
    return sh;
}
long long gtnbc(string &s,int &qs){
    long long sh=0,js=s.size();js--;
    while(qs<=js&&(s[qs]<'0'||'9'<s[qs]))qs++;
    while(qs<=js&&('0'<=s[qs]&&s[qs]<='9')){sh=(sh<<1)+(sh<<3)+(s[qs]^48);qs++;}
    return sh;
}
void ptnbc(string &s,long long zh,int opt=0){
    if(!zh){if(!opt){s+='0';}return;}
    int qw=zh%10;ptnbc(s,zh/10,1);s+=qw+'0';
}
bool chkc(char c){
    if((c<'0'||'9'<c)&&(c<'a'||'z'<c)&&(c<'A'||'Z'<c)&&c!='_')return false;
    return true;
}
string gtstrc(string &s,int &qs){
    string sh;int js=s.size();js--;
    while(qs<=js&&(!chkc(s[qs])))qs++;
    while(qs<=js&&chkc(s[qs])){sh+=s[qs];qs++;}
    return sh;
}
void pr(GtkWidget* widget,GdkEventKey *event,gpointer data){
    //cout<<"pr["<<event->keyval<<"]"<<endl;
    /*for(int i=0;i<4;i++)if(event->keyval==ajm[i]&&ajf[i]==0){ajf[i]=1;
        string ss;ptnbc(ss,nb);ss+=" 2 ";ptnbc(ss,mybh);ss+=" ";ss+=i+'0';ss+=" 1 ";
        fs.send(ss);
    }*/
    if(event->keyval==ajm[2]){gzbh--;if(gzbh<=0)gzbh=RS;}
    if(event->keyval==ajm[3]){gzbh++;if(gzbh>RS)gzbh=1;}
}
void rl(GtkWidget* widget,GdkEventKey *event,gpointer data){
    //cout<<"rl("<<event->keyval<<")"<<endl;
    /*for(int i=0;i<4;i++)if(event->keyval==ajm[i]&&ajf[i]==1){ajf[i]=0;
        string ss;ptnbc(ss,nb);ss+=" 2 ";ptnbc(ss,mybh);ss+=" ";ss+=i+'0';ss+=" 0 ";
        fs.send(ss);
    }*/
}
struct REN{
    string nm;
    int czflg,smz,sc,zx,zy,aj[4],fangx,pdd,bhh;
    GtkWidget *img,*nmlb;
    //double fx,fy,vx,vy,x,y;
};
REN rrr[10];
bool gz0(int x,int y){
    if(rrr[x].fangx==2&&rrr[y].fangx==2)return false;
    //if(rrr[x].fangx==2||rrr[y].fangx==2)return rrr[x].fangx>rrr[y].fangx;
    if(rrr[x].smz==rrr[y].smz){
        if(rrr[x].fangx==rrr[y].fangx){
            if(rrr[x].fangx==0)return rrr[x].zx<rrr[y].zx;
            return rrr[x].zx>rrr[y].zx;
        }
        return rrr[x].fangx>rrr[y].fangx;
    }return rrr[x].smz>rrr[y].smz;
}
bool gz1(int x,int y){
    if(rrr[x].sc==rrr[y].sc)return rrr[x].smz>rrr[y].smz;
    return rrr[x].sc>rrr[y].sc;
}    
struct GAME{
    const int rslim=8;
    int n,m,sd,op,smz,opy,t,p1,q1,p2,q2,rs,opz,rankk[10];
    GtkWidget *maimg[180][2];
    //double v0,a,v,nwh,xlim=2,ylim=0.5;
    //int sx[10];
    REN ren[10];
    vector<int>cswz;
    vector<vector<int> >ma;

    void xianshi(){
        gtk_widget_hide_all(fix);
        gtk_widget_show(fix);
        int zzx=0,zzy=0,kx=0,ky=0;
        //for(int i=1;i<=rs;i++)if(ren[i].bhh==mybh){zzx=ren[i].zx;zzy=ren[i].zy;}
        zzx=ren[gzbh].zx;zzy=ren[gzbh].zy;
        kx=zzx/20;ky=zzy/20;int tl[2]={-1,-1};
        for(int i=kx-6;i<=kx+6;i++){
            for(int j=ky-6;j<=ky+6;j++){
                if(i>=0&&i<=n+1&&j>=0&&j<=m+1){
                    if(ma[i][j]==1){
                        tl[0]++;gtk_fixed_move(GTK_FIXED(fix),maimg[tl[0]][0],92-zzy+j*20,92-zzx+i*20);
                        gtk_widget_show(maimg[tl[0]][0]);
                    }
                    else if(ma[i][j]==2){
                        tl[1]++;gtk_fixed_move(GTK_FIXED(fix),maimg[tl[1]][1],92-zzy+j*20,92-zzx+i*20);
                        gtk_widget_show(maimg[tl[1]][1]);
                    }
                }
            }
        }//exit(0);
        for(int i=1;i<=rs;i++){
            gtk_fixed_move(GTK_FIXED(fix),ren[i].img,92-zzy+ren[i].zy,92-zzx+ren[i].zx);
            gtk_widget_show(ren[i].img);
            gtk_fixed_move(GTK_FIXED(fix),ren[i].nmlb,92-zzy+ren[i].zy-10,92-zzx+ren[i].zx-10);
            gtk_widget_show(ren[i].nmlb);
        }
        string ss;
        for(int i=1;i<=rs;i++)rrr[i]=ren[i];
        if(!op){
            sort(rankk+1,rankk+rs+1,gz0);
            for(int ii=1;ii<=rs;ii++){
                int i=rankk[ii];ss+=i+'0';ss+=" ";
                ss+=ren[i].nm+":[";ptnbc(ss,ren[i].zx/20);ss+=",";ptnbc(ss,ren[i].zy/20);ss+="]";ptnbc(ss,ren[i].smz);
                if(ren[i].fangx==2)ss+=" finished\n";
                else if(ren[i].fangx==1)ss+=" v\n";
                else ss+=" ^\n";
            }
        }
        else if(op==1){
            sort(rankk+1,rankk+rs+1,gz1);
            for(int ii=1;ii<=rs;ii++){
                int i=rankk[ii];ss+=i+'0';ss+=" ";
                ss+=ren[i].nm+":[";ptnbc(ss,ren[i].zx/20);ss+=",";ptnbc(ss,ren[i].zy/20);ss+="](";ptnbc(ss,ren[i].smz);ss+=")";ptnbc(ss,ren[i].sc);ss+="\n";
            }            
        }gtk_label_set_text(GTK_LABEL(rking),ss.c_str());
    }    
    void init(){RS=rs;
        for(int i=1;i<=rs;i++)rankk[i]=i;
        mt19937 rnd(sd);
        ma.resize(n+2);
        //for(int i=1;i<=rslim;i++)sx[i]=i;
        for(int i=0;i<=n+1;i++)ma[i].resize(m+2);
        for(int i=1;i<=n;i++){
            for(int j=1;j<=m;j++){
                if(rnd()%q1<p1){
                    if(rnd()%q2<p2)ma[i][j]=2;
                    else ma[i][j]=1;
                }
            }
        }
        for(int i=0;i<=n+1;i++){
            if(!opy)ma[i][0]=ma[i][m+1]=1;
            else if(opy==1)ma[i][0]=ma[i][m+1]=2;
            else{
                if(rnd()%q2<p2){ma[i][0]=2;}else ma[i][0]=1;
                if(rnd()%q2<p2){ma[i][m+1]=2;}else ma[i][m+1]=1;                
            }
        }
        for(int i=1;i<=m;i++){ma[0][i]=ma[n+1][i]=1;if(op==1)ma[n+1][i]=2;}
        if(op==0){
            for(int i=1;i<=rslim;i++){ma[n][i]=0;ren[i].zx=n*20;ren[i].zy=i*20;}
        }
        else{
            for(int i=1;i<=n;i++){if(ma[i][0]==1){ma[i][1]=0;}if(ma[i][m+1]==1){ma[i][m]=0;}}
            for(int i=1;i<=n;i++){
                for(int j=1;j<=m;j++){
                    if(ma[i][j]!=1)continue;
                    if(ma[i-1][j-1]==1||ma[i-1][j+1]==1)ma[i][j]=0;
                }
            }
            for(int i=1;i<=m;i++)ma[1][i]=0;
            for(int i=2;i<=rslim+1;i++)ren[i].smz=smz;
            if(!opz){
                for(int i=2;i<=rslim+1;i++){ma[2][i]=1;/*ren[i].zx=20;ren[i].zy=20*i;*/}
            }
            else{
                for(int i=1;i<=m;i++){
                    for(int j=1;j<=n;j++){
                        if(ma[j][i]==1){cswz.push_back(i);break;}
                        if(ma[j][i]==2)break;
                    }
                }if(!cswz.size()){cswz.push_back(2);ma[2][2]=1;}
                //for(int i=2;i<=rslim+1;i++){ren[i].x=ren[i].zx=20;ren[i].y=ren[i].zy=cswz[randd(0,cswz.size()-1)]*20;}
            }
        }
        /*for(int i=0;i<=n+1;i++){
            for(int j=0;j<=m+1;j++){
                cout<<ma[i][j];
            }puts("");
        }exit(0);*/
    }
}gmo;
void ycl(){
    gtk_container_remove(GTK_CONTAINER(window),tb);
    gtk_widget_set_size_request(window,200,200);

    window1 = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window1),"Ranking");
    gtk_window_set_position(GTK_WINDOW(window1),GTK_WIN_POS_MOUSE);
    gtk_widget_set_size_request(window1,200,200);
    gtk_window_set_resizable(GTK_WINDOW(window1), FALSE);
    //g_signal_connect(window1,"destroy",G_CALLBACK(deal_close),NULL);
    //g_signal_connect(window1,"destroy",G_CALLBACK(gtk_main_quit),NULL);

    rking=gtk_label_new("qwq");
    gtk_container_add(GTK_CONTAINER(window1),rking);
    gtk_widget_show_all(window1);

    fix=gtk_fixed_new();
    gtk_container_add(GTK_CONTAINER(window),fix);
    //gtk_widget_show_all(window);

    const GdkPixbuf *bf;
    GdkPixbuf *bf1;
//exit(0);
    for(int i=0;i<=170;i++){
        bf=gdk_pixbuf_new_from_file("pic/z1.png",NULL);
        bf1=gdk_pixbuf_scale_simple(bf,20,20,GDK_INTERP_HYPER);
        gmo.maimg[i][0]=gtk_image_new_from_pixbuf(bf1);        
        bf=gdk_pixbuf_new_from_file("pic/z2.png",NULL);
        bf1=gdk_pixbuf_scale_simple(bf,20,20,GDK_INTERP_HYPER);
        gmo.maimg[i][1]=gtk_image_new_from_pixbuf(bf1);      
        //gmo.maimg[i][0]=gtk_image_new_from_file("z1.png");
        //gmo.maimg[i][1]=gtk_image_new_from_file("z2.png");
        gtk_fixed_put(GTK_FIXED(fix),gmo.maimg[i][0],0,0);
        gtk_fixed_put(GTK_FIXED(fix),gmo.maimg[i][1],0,0);
    }
    for(int i=1;i<=gmo.rslim;i++){
        string flnm="pic/r";flnm+=i+'0';flnm+=".png";
        bf=gdk_pixbuf_new_from_file(flnm.c_str(),NULL);
        bf1=gdk_pixbuf_scale_simple(bf,16,16,GDK_INTERP_HYPER);
        gmo.ren[i].img=gtk_image_new_from_pixbuf(bf1);
        gmo.ren[i].nmlb=gtk_label_new(gmo.ren[i].nm.c_str());
        gtk_fixed_put(GTK_FIXED(fix),gmo.ren[i].img,0,0);
        //gtk_fixed_put(GTK_FIXED(fix),gmo.ren[i].nmlb,0,0);
    }    
    for(int i=1;i<=gmo.rslim;i++){
        gtk_fixed_put(GTK_FIXED(fix),gmo.ren[i].nmlb,0,0);
    }    
    g_signal_connect(window,"key_press_event",G_CALLBACK(pr),NULL);
    g_signal_connect(window,"key_release_event",G_CALLBACK(rl),NULL);
    FILE *fp=fopen("opt.in","r");
    fscanf(fp,"%d%d%d%d",&ajm[0],&ajm[1],&ajm[2],&ajm[3]);
    fclose(fp);//exit(0);
}
bool gemo(){
    if(!ksflg){
        string ss;
        while(1){js.recv(ss);
            if(!ss.size())break;
            int nwwz=0;long long x=gtnbc(ss,nwwz);if(x!=nb)continue;
            x=gtnbc(ss,nwwz);if(x!=1)continue;
            ksflg=1;gmo.n=gtnbc(ss,nwwz);gmo.m=gtnbc(ss,nwwz);
            gmo.sd=gtnbc(ss,nwwz);gmo.op=gtnbc(ss,nwwz);gmo.opy=gtnbc(ss,nwwz);
            gmo.p1=gtnbc(ss,nwwz);gmo.q1=gtnbc(ss,nwwz);gmo.p2=gtnbc(ss,nwwz);
            gmo.q2=gtnbc(ss,nwwz);gmo.rs=gtnbc(ss,nwwz);gmo.opz=gtnbc(ss,nwwz);
            for(int i=1;i<=gmo.rs;i++)gmo.ren[i].nm=gtstrc(ss,nwwz);
            ycl();
            gmo.init();break;
        }
    }
    else{
        string ss;
        while(1){js.recv(ss);
            if(!ss.size())break;
            int nwwz=0;long long x=gtnbc(ss,nwwz);if(x!=nb)continue;
            x=gtnbc(ss,nwwz);if(x!=2)continue;
            for(int i=1;i<=gmo.rs;i++){gmo.ren[i].bhh=gtnbc(ss,nwwz);gmo.ren[i].zx=gtnbc(ss,nwwz);gmo.ren[i].zy=gtnbc(ss,nwwz);}
            if(!gmo.op){
                for(int i=1;i<=gmo.rs;i++){gmo.ren[i].smz=gtnbc(ss,nwwz);}
                for(int i=1;i<=gmo.rs;i++){gmo.ren[i].fangx=gtnbc(ss,nwwz);}
            }
            else{
                for(int i=1;i<=gmo.rs;i++){gmo.ren[i].smz=gtnbc(ss,nwwz);}
                for(int i=1;i<=gmo.rs;i++){gmo.ren[i].sc=gtnbc(ss,nwwz);}
            }
        }
        gmo.xianshi();
    }
    return true;
}
void deal_pressed(){
    gtk_widget_hide(nmqaq);
    gtk_widget_hide(nbqaq);
    nm=gtk_entry_get_text(GTK_ENTRY(srnm));nmlen=strlen(nm);
    if(nmlen>20||nmlen<1){gtk_widget_show(nmqaq);return;}
    for(int i=0;i<nmlen;i++){
        if((nm[i]<'0'||nm[i]>'9')&&(nm[i]<'a'||nm[i]>'z')&&(nm[i]<'A'||nm[i]>'Z')&&nm[i]!='_'){
            gtk_widget_show(nmqaq);return;
        }
    }int qw=1e9;
    Nb=gtk_entry_get_text(GTK_ENTRY(srnb));nblen=strlen(Nb);
    nb=gtnbgc(Nb,0,nblen-1);
    if(nb<0||nb>qw){gtk_widget_show(nbqaq);return;}
    //===========================================================================================
    /*string ss;mt19937_64 rnd(random_device{}());long long mod=1e18,zh=rnd()%mod;
    ptnbc(ss,nb);ss+=" 0 ";ptnbc(ss,zh);ss+=" ";
    for(int i=0;i<nmlen;i++)ss+=nm[i];
    UDPQWQ fss,jss;
    fss.port=port_out;fss.fsinit(10);
    jss.port=port_in;jss.jsinit(10); 
    fss.send(ss);usleep(200000);
    while(1){jss.recv(ss);
        if(!ss.size())break;
        int nwwz=0;long long x=gtnbc(ss,nwwz);if(x!=nb)continue;
        x=gtnbc(ss,nwwz);if(x!=0)continue;
        x=gtnbc(ss,nwwz);if(x!=zh)continue;
        mybh=gtnbc(ss,nwwz);break;
    }fss.cls();jss.cls();
    if(!mybh){gtk_widget_show(nbqaq);return;}*/
    //===========================================================================================
    timer=g_timeout_add(20,(GSourceFunc)gemo,NULL);
    waitt=gtk_label_new("Waiting for other players to join...");
    gtk_table_attach_defaults(GTK_TABLE(tb),waitt,0,2,0,5);
    gtk_widget_hide_all(tb);
    gtk_widget_show(waitt);gtk_widget_show(tb);
    fs.port=port_out;fs.fsinit(10);
    js.port=port_in;js.jsinit(10);    
}

void deal_close(){if(!mybh)return;
    string ss;ptnbc(ss,nb);ss+=" 1 ";ptnbc(ss,mybh);fs.send(ss);fs.cls();js.cls();
}
void init(){
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window),"ZHS AK JOISC!");
    gtk_window_set_position(GTK_WINDOW(window),GTK_WIN_POS_MOUSE);
    gtk_widget_set_size_request(window,400,200);
    gtk_window_set_resizable(GTK_WINDOW(window), FALSE);
    g_signal_connect(window,"destroy",G_CALLBACK(deal_close),NULL);
    g_signal_connect(window,"destroy",G_CALLBACK(gtk_main_quit),NULL);
    //==========================new window===============================
    lbnm=gtk_label_new("Name(0<len<21)(0~9||a~z||A~Z||_):");//gtk_label_set_justify(GTK_LABEL(lbnm),GTK_JUSTIFY_LEFT); 
    lbnb=gtk_label_new("Number(0~1e9):");//gtk_label_set_justify(GTK_LABEL(lbnb),GTK_JUSTIFY_LEFT); 
    nmqaq=gtk_label_new("QAQ!");
    nbqaq=gtk_label_new("QAQ!");
    srnm=gtk_entry_new();
    srnb=gtk_entry_new();
    qdbt=gtk_button_new_with_label("OK");
    tb=gtk_table_new(5,2,FALSE);
    gtk_container_add(GTK_CONTAINER(window),tb);
    gtk_table_attach_defaults(GTK_TABLE(tb),lbnm,0,1,0,1);gtk_widget_show(lbnm);
    gtk_table_attach_defaults(GTK_TABLE(tb),srnm,1,2,0,1);gtk_widget_show(srnm);
    gtk_table_attach_defaults(GTK_TABLE(tb),nmqaq,0,2,1,2);
    gtk_table_attach_defaults(GTK_TABLE(tb),lbnb,0,1,2,3);gtk_widget_show(lbnb);
    gtk_table_attach_defaults(GTK_TABLE(tb),srnb,1,2,2,3);gtk_widget_show(srnb);
    gtk_table_attach_defaults(GTK_TABLE(tb),nbqaq,0,2,3,4);
    gtk_table_attach_defaults(GTK_TABLE(tb),qdbt,0,2,4,5);gtk_widget_show(qdbt);
    g_signal_connect(qdbt,"pressed",G_CALLBACK(deal_pressed),NULL); 
    //==========================init window==============================
    gtk_widget_show(tb);
    gtk_widget_show(window);
}
int main( int argc,char *argv[] ) {
    gtk_init(&argc, &argv);
    //gtk_widget_show_all(window);
    init();
    gtk_main(); // 主事件循环 return 0;
}
//g++ -o orzwyz orzwyz.cpp -g -fsanitize=address `pkg-config --cflags --libs gtk+-2.0`